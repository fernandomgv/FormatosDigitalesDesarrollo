﻿
Partial Class CMSWebParts_MFS_regperfil
    Inherits System.Web.UI.UserControl

    Protected Sub TextBox3_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged


    End Sub
End Class
