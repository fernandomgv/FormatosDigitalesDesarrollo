﻿
Partial Class CMSWebParts_MFS_mensaje
    Inherits System.Web.UI.UserControl

End Class
